# Building LemonIPTV GitHub

This archive contains the app project from jia070310/lemonTV at 5be704224a2a102437811141d1ff6ec32a1dfd95, with the accompanying build.patch applied.

Use JDK 17, Android SDK platform 35 and Gradle 8.9. The Gradle wrapper and distribution SHA-256 are pinned to official Gradle downloads. Android Gradle Plugin 8.6.1, Kotlin 2.0.0 and Media3 1.5.1 remain as upstream. Guava is constrained to 33.7.2-android for CVE-2026-102554.

Set ANDROID_HOME and JAVA_HOME. For a signed release, provide KEYSTORE, KEYSTORE_PASSWORD, KEY_ALIAS and KEY_PASSWORD through your local process environment. Never commit the keystore or passwords. Run:

    gradlew.bat --no-daemon :app:assembleRelease :app:lintRelease

Alternatively use your own signing key; it will produce a different identity and cannot update an installation signed by another key. The owner's signing credentials are retained only on the owner's computer and are intentionally absent here.

The release identity is com.hwc0212.lemoniptv, version 1.1.11-hwc.1 (11101). The default source is https://raw.githubusercontent.com/hwc0212/iptv-live/main/channels.m3u. The unauthenticated server, trust-all TLS initialization and in-app APK installation paths are removed. See SECURITY-REVIEW.md and THIRD_PARTY_NOTICES.txt.

The source manifest records exact archived project-file bytes. This is buildable corresponding app source, not a promise of bit-for-bit reproducibility; signing, build environment and VCS metadata can change the APK digest. Third-party decoder source/build scripts and exact submodule commits are identified in THIRD_PARTY_NOTICES.txt.
